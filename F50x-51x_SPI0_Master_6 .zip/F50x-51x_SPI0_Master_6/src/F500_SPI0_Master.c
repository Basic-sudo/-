//-----------------------------------------------------------------------------
// F500_SPI0_Master.c
//-----------------------------------------------------------------------------
// Copyright 2014 Silicon Laboratories, Inc.
// http://developer.silabs.com/legal/version/v11/Silicon_Labs_Software_License_Agreement.txt
//
// Program Description:
// --------------------
// Use SPI as a 4-wire SPI Master.
//
// This program configures a C8051F500 as a 4-wire SPI Single Master.
//
// The SPI clock in this example is limited to 500 kHz when used with the
// SPI0_Slave code example.  During a SPI_Read, the slave needs some time to
// interpret the command and write the appropriate data to the SPI0DAT
// register, and the slave no longer has enough time to complete the
// SPI_READ_BUFFER command with a clock greater than 500 kHz.  For faster SPI
// clocks, a dummy byte between the command and the first byte of Read data
// will be required.
//
// This example is intended to be used with the SPI0_Slave example.
//
// Pinout:
//
// P0.0 - SPI SCK    (digital output, push-pull)
// P0.1 - SPI MISO   (digital input,  open-drain)
// P0.2 - SPI MOSI   (digital output, push-pull)
// P0.3 - SPI NSS    (digital output, push-pull)
//
// P1.3 - LED        (digital output, push-pull)
//
//
// How To Test:
// ------------
// 1) Ensure shorting blocks on C8051F500-TB are placed on the following:
//    J19: P1.3 LED
//    J7: Power selection, P4 9V (+5VREG) or P2 Debugger (SER_PWR)
// 2) Connect the USB Debug Adapter to P2. If +5VREG is selected on J7,
//    connect the 9V power adapter to P2.
// 3) Verify that the J22 jumper VREF is not populated.
//    If communicating with the other 'F50x device on the Target Board, also
//    remove J32.
//    If communicating with the other 'F50x device on the Target Board, verify
//    the LED pins of jumper J11 are populated.
// 4) Connect SPI bus to another device running the SPI0_Slave code.
// 5) Compile and download code to C8051F500-TB (either device A or device B)
//    with Simplicity IDE by selecting Run -> Debug from the menus,
//    or clicking the Debug button in the quick menu,
//    or pressing F11.
// 6) Run the code by selecting Run -> Resume from the menus,
//    or clicking the Resume button in the quick menu,
//    or pressing F8.
// 7) If the communication passes, the LEDs on both the Master and Slave
//    boards will blink slowly. If it fails, the LEDs will be OFF.
//
//
// Target:         C8051F50x/1x (Side A of a C8051F500-TB)
// Tool chain:     Simplicity Studio / Keil C51 9.51
// Command Line:   None
//
//
// Release 1.4 / 18 AUG 2014 (JL)
//    - Updated to use with Simplicity Studio
//
// Release 1.3 / 25 JAN 2013 (TP)
//    -Updated How to Test comments
//
// Release 1.2 / 02 MAR 2010 (GP)
//    -Tested with Raisonance
//
// Release 1.1 / 11 JUN 2008 (ADT)
//    -Edited Formatting
//
// Release 1.0 / 06 MAR 2008 (GP)
//    -Initial Revision


//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <SI_C8051F500_Register_Enums.h>
#include <intrins.h>
#include <stdio.h>
#include "deca_device_api.h"
#include "deca_regs.h"
#include "fifo.h"

//#define UWB_SENDER 0
#define UWB_SENDER 1

static dwt_config_t config = {
    2,               /* Channel number. */
    DWT_PRF_64M,     /* Pulse repetition frequency. */
    DWT_PLEN_128,   /* Preamble length. Used in TX only. */
    DWT_PAC8,       /* Preamble acquisition chunk size. Used in RX only. */
    9,               /* TX preamble code. Used in TX only. */
    9,               /* RX preamble code. Used in RX only. */
    1,               /* 0 to use standard SFD, 1 to use non-standard SFD. */
    DWT_BR_6M8,     /* Data rate. */
    DWT_PHRMODE_STD, /* PHY header mode. */
    (129 + DW_NS_SFD_LEN_6M8 - 8) /* SFD timeout (preamble length + 1 + SFD length - PAC size). Used in RX only. */
};

/* Default communication configuration. We use here EVK1000's default mode (mode 3). */
//static dwt_config_t config = {
//    2,               /* Channel number. */
//    DWT_PRF_64M,     /* Pulse repetition frequency. */
//    DWT_PLEN_1024,   /* Preamble length. Used in TX only. */
//    DWT_PAC32,       /* Preamble acquisition chunk size. Used in RX only. */
//    9,               /* TX preamble code. Used in TX only. */
//    9,               /* RX preamble code. Used in RX only. */
//    1,               /* 0 to use standard SFD, 1 to use non-standard SFD. */
//    DWT_BR_850K,     /* Data rate. */
//    DWT_PHRMODE_STD, /* PHY header mode. */
//    (1025 + DW_NS_SFD_LEN_850K - 32) /* SFD timeout (preamble length + 1 + SFD length - PAC size). Used in RX only. */
//};

static dwt_txconfig_t txconfig = {
    0xC2,            /* PG delay. */
    0x1F1F1F1F,      /* TX power. */ //MAX POWER
};

/* Buffer to store received frame. See NOTE 1 below. */
#define FRAME_LEN_MAX 8
static uint8 rx_buffer[FRAME_LEN_MAX];

/* Hold copy of status register state here for reference so that it can be examined at a debug breakpoint. */
static uint32 status_reg = 0;
static uint32 state_reg = 0;
/* Hold copy of frame length of frame received (if good) so that it can be examined at a debug breakpoint. */
static uint16 frame_len = 0;
static uint8 ADC[6];
static uint8 flag;


typedef union LONGDATA{                // Access LONGDATA as an
   unsigned long result;               // unsigned long variable or
   unsigned char Byte[4];              // 4 unsigned byte variables
}LONGDATA;

#define Byte3 0
#define Byte2 1
#define Byte1 2
#define Byte0 3

#define TIME0_NUM 2
uint8_t DELAY_FLAG = 0;

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------

#define SYSCLK             48000000    // Internal oscillator frequency in Hz
#define BAUDRATE            1000000     // Baud rate of UART in bps
//#define SPI_CLOCK          500000

#define SPI_CLOCK          500000      // Maximum SPI clock
                                       // The SPI clock is a maximum of 500 kHz
                                       // when this example is used with
                                       // the SPI0_Slave code example.
#define  F_SCK_l         3000000     // Max SCK freq (Hz)500k
//#define  F_SCK_h         12250000    // Max SCK freq (Hz)
#define  F_SCK_h         12000000   // Max SCK freq (Hz)12250000
#define  ADC_CLK         3600000

#define MAX_BUFFER_SIZE    8           // Maximum buffer Master will send

// Instruction Set
#define  SLAVE_LED_ON      0x01        // Turn the Slave LED on
#define  SLAVE_LED_OFF     0x02        // Turn the Slave LED off
#define  SPI_WRITE         0x04        // Send a byte from the Master to the
                                       // Slave
#define  SPI_READ          0x08        // Send a byte from the Slave to the
                                       // Master
#define  SPI_WRITE_BUFFER  0x10        // Send a series of bytes from the
                                       // Master to the Slave
#define  SPI_READ_BUFFER   0x20        // Send a series of bytes from the Slave
                                       // to the Master
#define  ERROR_OCCURRED    0x40        // Indicator for the Slave to tell the
                                       // Master an error occurred

#define FRAME_LEN 6

void uart_send(uint8 byte)
{
   while (!SCON0_TI);
   SCON0_TI = 0;
   SBUF0 = byte;
}

void uint32_to_uint8_array(uint32 dat)
{
  ADC[1] = (dat >> 16) & 0xFF;   // Extract the second highest byte
  ADC[2] = (dat >> 8) & 0xFF;   // Extract the second lowest byte
  ADC[3] = dat & 0xFF;          // Extract the lowest byte
  flag = 1;
}

SI_SBIT(DW1000_RST, SFR_P1, 3);
SI_SBIT(rset, SFR_P1, 3);
SI_SBIT(led1, SFR_P2, 1);
SI_SBIT(led2, SFR_P2, 0);
SI_SBIT(led3, SFR_P1, 7);

SI_SBIT(Delay_IO, SFR_P0, 3);

//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------

uint8_t SPI_Data = 0xA5;

uint8_t SPI_Data_Array[MAX_BUFFER_SIZE] = {0};

bit Error_Flag = 0;

uint8_t Command = 0x00;

//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------

void PCA0_Init (void);
void OSCILLATOR_Init (void);
void PORT_Init (void);
void SPI0_Init (void);
void Init_Device (void);

void SPI_LED_On (void);
void SPI_LED_Off (void);
void SPI_Byte_Write (void);
void SPI_Byte_Read (void);
void SPI_Array_Write (void);
void SPI_Array_Read (void);

void Delay(void);

void reset_DW1000(void);
void spi_set_rate_low (void);
void spi_set_rate_high (void);

void UART0_Init (void);
void ADC0_Init (void);
void TIMER2_Init (void);
void TIMER0_Init (void);

#define BLINK_FRAME_SN_IDX 1

SI_INTERRUPT_PROTO(ADC0_ISR, INTERRUPT_ADC0_EOC);
//SI_INTERRUPT_PROTO(SPI0_ISR, SPI0_IRQn);
SI_INTERRUPT_PROTO(Timer0_ISR, TIMER0_IRQn);

//-----------------------------------------------------------------------------
// SiLabs_Startup() Routine
// ----------------------------------------------------------------------------
// This function is called immediately after reset, before the initialization
// code is run in SILABS_STARTUP.A51 (which runs before main() ). This is a
// useful place to disable the watchdog timer, which is enable by default
// and may trigger before main() in some instances.
//-----------------------------------------------------------------------------
void SiLabs_Startup (void)
{
   PCA0MD &= ~PCA0MD_WDTE__ENABLED;    // Disable the Watchdog Timer
}

int result = 1000;
uint8_t read_array[MAX_BUFFER_SIZE];
//-----------------------------------------------------------------------------
// main() Routine
//-----------------------------------------------------------------------------
void main (void)
{
  uint8 i = 1;
  uint32 num = 0;
  uint8_t test_array[MAX_BUFFER_SIZE] = {1,2,3,4,5,6,7,8};
  uint8_t test_array2[1] = {1};

  Init_Device ();                     // Initializes hardware peripherals
  IE_EA = 1;                          // Enable global interrupts
  reset_DW1000();
  spi_set_rate_low ();
  while(dwt_initialise(DWT_LOADUCODE) != DWT_SUCCESS)
    {
      deca_sleep(5);
    }
  spi_set_rate_high();
  dwt_configure(&config);
  dwt_setsmarttxpower(1);  //disable smart TX
  dwt_configuretxrf(&txconfig);
  dwt_write32bitreg(0x26, 0xde054000);                        //CRC校验使能在这个寄存器中配置完成
  uart_send("a");
  while(1)
    {
      #if UWB_SENDER

      dwt_writetxdata(sizeof(ADC), ADC, 0); /* Zero offset in TX buffer. */
      dwt_writetxfctrl(sizeof(ADC), 0, 0); /* Zero offset in TX buffer, no ranging. */
      dwt_starttx(DWT_START_TX_IMMEDIATE);

      while (!((flag = dwt_read32bitreg(SYS_STATUS_ID)) & SYS_STATUS_TXFRS))
        {};
      dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_TXFRS);
    }
#else
  dwt_rxenable(DWT_START_RX_IMMEDIATE);
  while (!((status_reg = dwt_read32bitreg(SYS_STATUS_ID)) & (SYS_STATUS_RXFCG | SYS_STATUS_ALL_RX_ERR)))
    {}
  if (status_reg & SYS_STATUS_RXFCG){
      frame_len = dwt_read32bitreg(RX_FINFO_ID) & RX_FINFO_RXFL_MASK_1023;
      if (frame_len <= FRAME_LEN_MAX)
        {
          dwt_readrxdata(rx_buffer, frame_len, 0);
          for (i = 0; i < frame_len; i++) {
              if((rx_buffer[0] == 0xFF) & (rx_buffer[3] == 0xEE))
                {
                  uart_send(rx_buffer[0]);
                  uart_send(rx_buffer[1]);
                  uart_send(rx_buffer[2]);
                  uart_send(rx_buffer[3]);
                  uart_send(rx_buffer[4]);
                  uart_send(rx_buffer[5]);
                }
          }
        }
      dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_RXFCG);
  }
  else
  {
      dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_ALL_RX_ERR);
  }
}
#endif
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// PCA0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function disables the watchdog timer.
//
//-----------------------------------------------------------------------------
void PCA0_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;

   SFRPAGE = LEGACY_PAGE;

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// OSCILLATOR_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function initializes the system clock to use the internal oscillator
// at 24 MHz.
//
//-----------------------------------------------------------------------------
void OSCILLATOR_Init (void)
{
  uint8_t SFRPAGE_save = SFRPAGE;
  uint8_t i = 0;
  SFRPAGE = CONFIG_PAGE;

  // Set internal oscillator to run at its maximum frequency
  OSCICN = 0xC7;

  CLKMUL = 0x00;
  CLKMUL |= CLKMUL_MULSEL__HFOSC;
  CLKMUL |= CLKMUL_MULDIV__DIV_HALF;
  CLKMUL |= CLKMUL_MULEN__ENABLED;
  //deca_sleep(5);
  for(; i < 10; i++) {
      _nop_();
  }
  CLKMUL |= CLKMUL_MULEN__ENABLED | CLKMUL_MULINIT__SET;
  while (!(CLKMUL | CLKMUL_MULRDY__BMASK)) {
  }

  CLKSEL |= CLKSEL_CLKSL__CLKMUL;                //Clock Multiplier

  RSTSRC = 0x04;

  SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function configures the crossbar and GPIO ports.
//
// P0.0  -  SCK  (SPI0), Push-Pull,  Digital
// P0.1  -  MISO (SPI0), Open-Drain, Digital
// P0.2  -  MOSI (SPI0), Push-Pull,  Digital
// P0.3  -  NSS  (SPI0), Push-Pull,  Digital
//
// P1.3  -  Skipped,     Push-Pull,  Digital (LED on Target Board)
//
//-----------------------------------------------------------------------------
void PORT_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;

   P0MDIN    = 0xF8;
   P0MDOUT   = 0x50;
   P1MDOUT   = 0x8B;
   P2MDOUT   = 0x03;
   P0SKIP    = 0x0F;
   XBR0      = 0x05;
   XBR2      = 0x40;

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configures SPI0 to use 4-wire Single Master mode. The SPI timing is
// configured for Mode 0,0 (data centered on first edge of clock phase and
// SCK line low in idle state).
//
//-----------------------------------------------------------------------------
void SPI0_Init()
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   SPI0CFG   = 0x40;
   SPI0CN    = 0x0D;
   SPI0CKR   = 0x01;

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// Init_Device
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Calls all device initialization functions.
//
//-----------------------------------------------------------------------------
void Init_Device (void)
{
   PCA0_Init ();                       // Disable the Watchdog Timer first
   OSCILLATOR_Init ();
   PORT_Init ();
   SPI0_Init ();
   UART0_Init();
   ADC0_Init();
   TIMER2_Init();
   TIMER0_Init();
}

//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SPI_ISR
//-----------------------------------------------------------------------------
//
// Handles all error checks and single-byte writes.
//
// Note: SPI_WRITE_ARRAY is not handled by this ISR in order to take
// advantage of double-buffering (checking the TXBMT flag) using polling.
//
//
// Typical Write:
//
//              | 1st sent | 2nd sent | 3rd sent |   ...    | last sent |
//              ---------------------------------------------------------
//  Master NSSv | Command  |   Data1  |   Data2  |   ...    |   DataN   |  NSS^
//  Slave       |   N/A    |    N/A   |    N/A   |   ...    |    N/A    |
//
// Typical Read:
//
//              | 1st sent | 2nd sent | 3rd sent |   ...    | last sent |
//              ---------------------------------------------------------
//  Master NSSv | Command  |   dummy  |   dummy  |   ...    |   dummy   |  NSS^
//  Slave       |   N/A    |   Data1  |   Data2  |   ...    |   DataN   |
//-----------------------------------------------------------------------------
SI_INTERRUPT(SPI0_ISR, SPI0_IRQn)
{

}

//-----------------------------------------------------------------------------
// Support Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SPI_LED_On
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Turns the LED on the SPI Slave on.  The slave does not respond to this
// command, so the command consists of:
//
// Command = SLAVE_LED_ON
// Length = 1 byte (the command itself)
//
//-----------------------------------------------------------------------------
void SPI_LED_On (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy
   SPI0CN_NSSMD0 = 0;

   Command = SLAVE_LED_ON;

   SPI0DAT = Command;

   // The rest of this command will be handled by the SPI ISR, which will
   // trigger when SPIF is set from sending the Command

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI_LED_Off
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Turns the LED on the SPI Slave off.  The slave does not respond to this
// command, so the command consists of:
//
// Command = SLAVE_LED_OFF
// Length = 1 byte (the command itself)
//
//-----------------------------------------------------------------------------
void SPI_LED_Off (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy
   SPI0CN_NSSMD0 = 0;

   Command = SLAVE_LED_OFF;

   SPI0DAT = Command;

   // The rest of this command will be handled by the SPI ISR, which will
   // trigger when SPIF is set from sending the Command

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI_Byte_Write
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Note: SPI_Data must contain the data to be sent before calling this
// function.
//
// Writes a single byte to the SPI Slave.  The slave does not respond to this
// command, so the command consists of:
//
// Command = SPI_WRITE
// Length = 1 byte of command, 1 byte of data
//
//-----------------------------------------------------------------------------
void SPI_Byte_Write (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy

   SPI0CN_NSSMD0 = 0;

   Command = SPI_WRITE;

   SPI0DAT = Command;

   // The rest of this command will be handled by the SPI ISR, which will
   // trigger when SPIF is set from sending the Command

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI_Byte_Read
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Note: SPI_Data will contain the data received after calling this function.
//
// Reads a single byte from the SPI Slave.  The command consists of:
//
// Command = SPI_READ
// Length = 1 byte of command, 1 byte of data
//
//-----------------------------------------------------------------------------
void SPI_Byte_Read (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy
   SPI0CN_NSSMD0 = 0;

   Command = SPI_READ;

   SPI0DAT = Command;

   // The rest of this command will be handled by the SPI ISR, which will
   // trigger when SPIF is set from sending the Command

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI_Array_Write
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Note: SPI_Data_Array must contain the data to be sent before calling this
// function.
//
// Writes an array of values of size MAX_BUFFER_SIZE to the SPI Slave.  The
// command consists of:
//
// Command = SPI_WRITE_BUFFER
// Length = 1 byte of command, MAX_BUFFER_SIZE bytes of data
//
// Note: Polled mode is used for this function in order to buffer the data
// being sent using the TXBMT flag.
//
//-----------------------------------------------------------------------------
void SPI_Array_Write (void)
{
   uint8_t array_index;

   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy
   IE_ESPI0 = 0;                       // Disable SPI interrupts

   SPI0CN_NSSMD0 = 0;

   SPI0DAT = SPI_WRITE_BUFFER;         // Load the XMIT register
   while (SPI0CN_TXBMT != 1)           // Wait until the command is moved into
   {                                   // the XMIT buffer
   }

   for (array_index = 0; array_index < MAX_BUFFER_SIZE; array_index++)
   {
      SPI0DAT = SPI_Data_Array[array_index]; // Load the data into the buffer
      while (SPI0CN_TXBMT != 1)        // Wait until the data is moved into
      {                                // the XMIT buffer
      }
   }
   SPI0CN_SPIF = 0;
   while (SPI0CN_SPIF != 1)            // Wait until the last byte of the
   {                                   // data reaches the Slave
   }
   SPI0CN_SPIF = 0;

   SPI0CN_NSSMD0 = 1;                  // Diable the Slave

   IE_ESPI0 = 1;                       // Re-enable SPI interrupts

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// SPI_Array_Read
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Note: SPI_Data_Array will contain the data received after calling this
// function.
//
// Reads a single byte from the SPI Slave.  The command consists of:
//
// Command = SPI_READ_BUFFER
// Length = 1 byte of command, MAX_BUFFER_SIZE bytes of data
//
//-----------------------------------------------------------------------------
void SPI_Array_Read (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   while (!SPI0CN_NSSMD0);             // Wait until the SPI is free, in case
                                       // it's already busy

   SPI0CN_NSSMD0 = 0;

   Command = SPI_READ_BUFFER;

   SPI0DAT = Command;

   // The rest of this command will be handled by the SPI ISR, which will
   // trigger when SPIF is set from sending the Command

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// Delay
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Delay for little while (used for blinking the LEDs)
//
//-----------------------------------------------------------------------------
void Delay (void)
{
   uint32_t count;

   for (count = 200000; count > 0; count--);
}

void reset_DW1000(void)
{
  //dw1000:
//  P0MDOUT |= 0x08;      //dw1000,rst push-pull

  DW1000_RST = 0;

  deca_sleep(500);

  DW1000_RST = 1;

//  P0MDIN  &= 0xF7;      //dw1000,rst simulate
  //drive the RSTn pin low
  deca_sleep(500);

}

void spi_set_rate_low (void)
{
  uint8_t SFRPAGE_save = SFRPAGE;
  SFRPAGE = LEGACY_PAGE;

  SPI0CKR = (SYSCLK/(2*F_SCK_l))-1;

  SFRPAGE = SFRPAGE_save;
}

void spi_set_rate_high (void)
{
  uint8_t SFRPAGE_save = SFRPAGE;
  SFRPAGE = LEGACY_PAGE;

  SPI0CKR = (SYSCLK/(2*F_SCK_h))-1;

  SFRPAGE = SFRPAGE_save;
}

void TIMER2_Init (void)
{
//  CKCON |= CKCON_T2ML__SYSCLK;
  uint8_t SFRPAGE_save = SFRPAGE;
  SFRPAGE = LEGACY_PAGE;

  TMR2CN = 0x00;                      // Stop Timer2; Clear TF2;
                                      // use SYSCLK as timebase, 16-bit
                                      // auto-reload
  CKCON |= CKCON_T2ML__SYSCLK;        // Select SYSCLK for Timer 2 source
  TMR2RL = 65535 - (SYSCLK / 10000);     // Init reload value for 20 us
  TMR2   = 0xFFFF;                    // Set to reload immediately
  TMR2CN_TR2 = 1;                     // Start Timer2

  SFRPAGE = SFRPAGE_save;
}

void ADC0_Init (void)                            //例程
{
   uint8_t SFRPAGE_save = SFRPAGE;
//   SFRPAGE = LEGACY_PAGE;
//
//   // Initialize the Gain to account for a 5V input and 2.25 VREF
//   // Solve the equation provided in Section 6.3.1 of the Datasheet
//
//   // The 5V input is scaled by a factor of 0.44 so that the maximum input
//   // voltage seen by the pin is 2.2V
//
//   // 0.44 = (GAIN/4096) + GAINADD * (1/64)
//
//   // Set GAIN to 0x6CA and GAINADD to 1
//   // GAIN = is the 12-bit word formed by ADC0GNH[7:0] ADC0GNL[7:4]
//   // GAINADD is bit ADC0GNA.0
//
//   ADC0CF |= ADC0CF_GAINEN__ENABLED;   // Set GAINEN = 1
//   ADC0H   = 0x04;                     // Load the ADC0GNH address
//   ADC0L   = 0x6C;                     // Load the upper byte of 0x6CA
//   ADC0H   = 0x07;                     // Load the ADC0GNL address
//   ADC0L   = 0xA0;                     // Load the lower nibble of 0x6CA
//   ADC0H   = 0x08;                     // Load the ADC0GNA address
//   ADC0L   = 0x01;                     // Set the GAINADD bit
//   ADC0CF &= ~ADC0CF_GAINEN__BMASK;    // Set GAINEN = 0
//
//   // ADC0 disabled, normal tracking, conversion triggered on TMR2 overflow
//   // Output is right-justified
//   ADC0CN = ADC0CN_ADLJST__RIGHT |
//            ADC0CN_ADCM__TIMER2;
//
//   // Use external voltage reference
////   REF0CN = REF0CN_ZTCEN__FORCE_ENABLED |
////              REF0CN_BIASE__ENABLED ;
//   REF0CN = REF0CN_ZTCEN__FORCE_ENABLED |
//            REF0CN_REFLV__2P2 |
//            REF0CN_BIASE__ENABLED |
//            REF0CN_REFBE__ENABLED;
//   ADC0MX = 0x01;  // Set ADC input to initial setting
//
//   ADC0CF = ((SYSCLK / 3000000) - 1) << 3; // Set SAR clock to ADC_CLK
//
//   EIE1 |= EIE1_EADC0__ENABLED;        // Enable ADC0 conversion complete int.
//
//   ADC0CN_ADEN = 1;                    // Enable ADC0
//
//   SFRPAGE = SFRPAGE_save;

  ADC0CF |= ADC0CF_GAINEN__ENABLED;   // Set GAINEN = 1
  ADC0H   = 0x04;                     // Load the ADC0GNH address
  ADC0L   = 0xFC;                     // Load the upper byte of 0x6CA to
                                      // ADC0GNH
  ADC0H   = 0x07;                     // Load the ADC0GNL address
  ADC0L   = 0x00;                     // Load the lower nibble of 0x6CA to
                                      // ADC0GNL
  ADC0H   = 0x08;                     // Load the ADC0GNA address
  ADC0L   = 0x01;                     // Set the GAINADD bit
  ADC0CF &= ~ADC0CF_GAINEN__BMASK;    // Set GAINEN = 0

  // ADC0 disabled, normal tracking, conversion triggered on TMR2 overflow
  // Output is right-justified
  ADC0CN = ADC0CN_ADLJST__RIGHT |
           ADC0CN_ADCM__TIMER2;

  // Enable on-chip VREF and buffer, set voltage reference to 2.2V
  REF0CN = REF0CN_ZTCEN__FORCE_ENABLED;

  ADC0MX = 0x01;                      // Set ADC input to P1.2

  ADC0CF = ((SYSCLK / 3000000) - 1) << 3; // Set SAR clock to 3MHz

  EIE1 |= EIE1_EADC0__ENABLED;        // Enable ADC0 conversion complete int.

  ADC0CN_ADEN = 1;                    // Enable ADC0

  SFRPAGE = SFRPAGE_save;

}

void UART0_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;

   SCON0 = 0x10;                       // SCON0: 8-bit variable bit rate
                                       // clear RI0 and TI0 bits

   // Baud Rate = [BRG Clock / (65536 - (SBRLH0:SBRLL0))] x 1/2 x 1/Prescaler

#if   ((SYSCLK / BAUDRATE / 2 / 0xFFFF) < 1)
      SBRL0 = -(SYSCLK / BAUDRATE / 2);
      SBCON0 |= 0x03;                  // Set prescaler to 1
#elif ((SYSCLK / BAUDRATE / 2 / 0xFFFF) < 4)
      SBRL0 = -(SYSCLK / BAUDRATE / 2 / 4);
      SBCON0 &= ~0x03;
      SBCON0 |= 0x01;                  // Set prescaler to 4
#elif ((SYSCLK / BAUDRATE / 2 / 0xFFFF) < 12)
      SBRL0 = -(SYSCLK / BAUDRATE / 2 / 12);
      SBCON0 &= ~0x03;                 // Set prescaler to 12
#else
      SBRL0 = -(SYSCLK / BAUDRATE / 2 / 48);
      SBCON0 &= ~0x03;
      SBCON0 |= 0x02;                  // Set prescaler to 48
#endif

   SBCON0 |= SBCON0_SBRUN__ENABLED;    // Enable baud rate generator
   SCON0_TI = 1;                       // Indicate TX0 ready

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
// ADC0_ISR
//-----------------------------------------------------------------------------
//
// This ISR averages 2048 samples then prints the result to the terminal.  The
// ISR is called after each ADC conversion which is triggered by Timer2.
//
//-----------------------------------------------------------------------------


SI_INTERRUPT(ADC0_ISR, ADC0EOC_IRQn)
{
   uint32_t mV = 0;
   uint32_t result = 0;
   ADC0CN_ADINT = 0;                  // Clear ADC0 conv. complete flag

   result = ADC0;                // Add most recent sample

   mV =  result  / 4095 * 2500;

   // SFR page is already correct for printf (SBUF0 page)
   printf("P1.2 voltage: %ld mV\n", mV);

   ADC[0] = 0xFF;           //添加包头

   ADC[1] = 0x0F & (result >> 8);    //16位扩充   取高八位         1010  0101  1111  右移
   ADC[2] = 0xFF &  result;

   ADC[3] = 0xEE;
   ADC[4] = 0;
   ADC[5] = 0;

   ADC0CN_ADINT = 0;
}


void TIMER0_Init (void)
{
   TH0 = 0x00;                         // Init Timer0 reload register
   TL0 = TH0;                          // Set the intial Timer0 value

   TMOD  = 0x02;                       // Timer0 in 8-bit reload mode
   CKCON = CKCON_SCA__SYSCLK_DIV_48;   // Timer0 uses a 1:48 prescaler
   IE_ET0 = 1;                         // Timer0 interrupt enabled
   TCON  = TCON_TR0__RUN;              // Timer0 ON
}

SI_INTERRUPT(Timer0_ISR, TIMER0_IRQn)
{
   // The Timer0 interrupt flag is automatically cleared by vectoring to
   // the Timer0 ISR

   static uint8_t count = 0;

//   count++;
//   if (count == TIME0_NUM)
//   {
//       count = 0;
//   }

   if(DELAY_FLAG == 1)
   {
       count = 0;
       count++;
       DELAY_FLAG = 2;

   }
   else if(DELAY_FLAG == 2)
   {
       count++;
       if (count == TIME0_NUM)
       {
           DELAY_FLAG = 3;
       }

   }
}

void deca_sleep(unsigned int time_ms)
{
  unsigned int i;

  for(i=0; i<time_ms; i++)
  {
      DELAY_FLAG = 1;
      while(DELAY_FLAG != 3)
      {

      }
  }
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
