#include "fifo.h"

CFG_FIGO_ELEM_TYPE fifo_pop(struct fifo *fifo)
{
  // 队列已空时返回0
  if(fifo->size == 0)
    return 0;

  (fifo->size)--;

#if CFG_FIFO_MEMALLOC
  if(fifo->head  < fifo->buf_size  - 1) {
#else
  if(fifo->head  < CFG_FIFO_SIZE  - 1) {
#endif
    (fifo->head)++;
    return (fifo->buf)[(fifo->head)-1];
  }
  else {
    fifo->head = 0;
#if CFG_FIFO_MEMALLOC
    return (fifo->buf)[fifo->buf_size  - 1];
#else
    return (fifo->buf)[CFG_FIFO_SIZE  - 1];
#endif
  }
}

CFG_FIGO_ELEM_TYPE fifo_get(struct fifo *fifo, uint8_t idx)
{
  if(idx >= fifo->size)
    return fifo->size;

#if CFG_FIFO_MEMALLOC
  if((fifo->head) + idx < fifo->buf_size)
    return (fifo->buf)[(fifo->head) + idx];
  else
    return (fifo->buf)[(fifo->head) + idx - (fifo->buf_size)];
#else
  if((fifo->head) + idx < CFG_FIFO_SIZE)
    return (fifo->buf)[(fifo->head) + idx];
  else
    return (fifo->buf)[(fifo->head) + idx - CFG_FIFO_SIZE];
#endif
}
